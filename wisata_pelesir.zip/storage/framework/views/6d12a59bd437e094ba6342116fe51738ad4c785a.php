<?php $__env->startSection('konten'); ?>
<h3>Data Daerah</h3>

<a href="/backend/daerah/tambah">+ Tambah Data</a>

<br>

<table border="1">
	<tr>
		<th>ID</th>
		<th>Nama daerah</th>
		<th>Opsi</th>
	</tr>
	<?php $__currentLoopData = $daerah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td><?php echo e($d->id_daerah); ?></td>
		<td><?php echo e($d->nama_daerah); ?></td>
		<td>
			<a href="/backend/daerah/edit/<?php echo e($d->id_daerah); ?>">Edit</a>
			|
			<a href="/backend/daerah/hapus/<?php echo e($d->id_daerah); ?>">Hapus</a>
		</td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wisata_pelesir\resources\views/index_daerah.blade.php ENDPATH**/ ?>