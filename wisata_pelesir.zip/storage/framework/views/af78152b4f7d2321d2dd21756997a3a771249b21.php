<?php $__env->startSection('konten'); ?>
	<h3>Tambah Data Pengguna</h3>
	<br>

	<form action="/backend/pengguna/store" method="post">
		<?php echo e(csrf_field()); ?>

		ID :
		<input type="text" name="id" required="required">
		<br>
		Nama :
		<input type="text" name="nama" required="required">
		<br>
		Password :
		<input type="text" name="password" required="required">
		<br>
		No telp :
		<input type="text" name="no_telp" required="required">
		<br>
		Email :
		<input type="text" name="email" required="required">
		<br>
		Foto :
		<input type="text" name="foto" required="required">
		<br>
		<a href="/backend/pengguna"><button type="button">Back</button></a>
		|
		<input type="submit" value="Simpan Data">
	</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wisata_pelesir\resources\views/tambah_pengguna.blade.php ENDPATH**/ ?>