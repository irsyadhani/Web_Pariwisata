<?php $__env->startSection('konten'); ?>
<h3>Data Jadwal Buka</h3>

<a href="/backend/jadwal_buka/tambah">+ Tambah Data</a>

<br>

<table border="1">
	<tr>
		<th>ID Jadwal</th>
		<th>ID Pariwisata</th>
		<th>Hari Buka</th>
		<th>Jam Buka</th>
		<th>Jam Tutup</th>
		<th>Opsi</th>
	</tr>
	<?php $__currentLoopData = $jadwal_buka; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td><?php echo e($jb->id_jadwal); ?></td>
		<td><?php echo e($jb->id_pariwisata); ?></td>
		<td><?php echo e($jb->hari_buka); ?></td>
		<td><?php echo e($jb->jam_buka); ?></td>
		<td><?php echo e($jb->jam_tutup); ?></td>
		<td>
			<a href="/backend/jadwal_buka/edit/<?php echo e($jb->id_jadwal); ?>">Edit</a>
			|
			<a href="/backend/jadwal_buka/hapus/<?php echo e($jb->id_jadwal); ?>">Hapus</a>
		</td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wisata_pelesir\resources\views/index_jadwal_buka.blade.php ENDPATH**/ ?>