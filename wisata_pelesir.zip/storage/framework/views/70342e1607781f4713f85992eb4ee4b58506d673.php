<?php $__env->startSection('konten'); ?>
<h3>Data Review</h3>

<a href="/backend/review/tambah">+ Tambah Data</a>

<br>

<table border="1">
	<tr>
		<th>ID Review</th>
		<th>ID Pengguna</th>
		<th>ID Pariwisata</th>
		<th>Status</th>
		<th>Rating</th>
		<th>Deskripsi</th>
		<th>Opsi</th>
	</tr>
	<?php $__currentLoopData = $review; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td><?php echo e($r->id_review); ?></td>
		<td><?php echo e($r->id_pengguna); ?></td>
		<td><?php echo e($r->id_pariwisata); ?></td>
		<td><?php echo e($r->status); ?></td>
		<td><?php echo e($r->rating_review); ?></td>
		<td><?php echo e($r->deskripsi_review); ?></td>
		<td>
			<a href="/backend/review/edit/<?php echo e($r->id_review); ?>">Edit</a>
			|
			<a href="/backend/review/hapus/<?php echo e($r->id_review); ?>">Hapus</a>
		</td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wisata_pelesir\resources\views/index_review.blade.php ENDPATH**/ ?>