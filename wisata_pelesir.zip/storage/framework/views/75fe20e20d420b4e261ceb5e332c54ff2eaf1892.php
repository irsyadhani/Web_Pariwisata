<?php $__env->startSection('konten'); ?>
	<h3>Edit Data Pengguna</h3>
	<br>

	<?php $__currentLoopData = $pengguna; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<form action="/backend/pengguna/update" method="post">
			<?php echo e(csrf_field()); ?>

			<input type="hidden" name="id" value="<?php echo e($p->id_pengguna); ?>">
			<br>
			Nama :
			<input type="text" name="nama" value="<?php echo e($p->nama_pengguna); ?>" required="required">
			<br>
			Password :
			<input type="text" name="password" value="<?php echo e($p->kata_sandi); ?>" required="required">
			<br>
			No telp :
			<input type="text" name="no_telp" value="<?php echo e($p->no_telp); ?>" required="required">
			<br>
			Email :
			<input type="text" name="email" value="<?php echo e($p->email); ?>" required="required">
			<br>
			Foto :
			<input type="text" name="foto" value="<?php echo e($p->foto_pengguna); ?>" required="required">
			<br>
			<a href="/backend/pengguna"><button type="button">Back</button></a>
			|
			<input type="submit" value="Simpan Data">
		</form>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wisata_pelesir\resources\views/edit_pengguna.blade.php ENDPATH**/ ?>