<?php $__env->startSection('konten'); ?>
<h3>Data Kategori</h3>

<a href="/backend/kategori/tambah">+ Tambah Data</a>

<br>

<table border="1">
	<tr>
		<th>ID</th>
		<th>Nama kategori</th>
		<th>Opsi</th>
	</tr>
	<?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td><?php echo e($d->id_kategori); ?></td>
		<td><?php echo e($d->nama_kategori); ?></td>
		<td>
			<a href="/backend/kategori/edit/<?php echo e($d->id_kategori); ?>">Edit</a>
			|
			<a href="/backend/kategori/hapus/<?php echo e($d->id_kategori); ?>">Hapus</a>
		</td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wisata_pelesir\resources\views/index_kategori.blade.php ENDPATH**/ ?>