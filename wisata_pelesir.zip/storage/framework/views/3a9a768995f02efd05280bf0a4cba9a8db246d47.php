<?php $__env->startSection('konten'); ?>
<h3>Data Detail Pariwisata</h3>

<a href="/backend/detail_pariwisata">+ Tambah Data</a>

<br>

<table border="1">
	<tr>
		<th>ID Pariwsata</th>
		<th>ID Kategori</th>
	</tr>
	<?php $__currentLoopData = $detail_pariwisata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td><?php echo e($dp->id_pariwisata); ?></td>
		<td><?php echo e($dp->id_kategori); ?></td>
		
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wisata_pelesir\resources\views/index_detail_pariwisata.blade.php ENDPATH**/ ?>