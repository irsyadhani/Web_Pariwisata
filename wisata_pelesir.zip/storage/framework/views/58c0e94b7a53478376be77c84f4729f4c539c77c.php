<?php $__env->startSection('konten'); ?>
<h3>Data Pariwisata</h3>

<a href="/backend/pariwisata/tambah">+ Tambah Data</a>

<br>

<table border="1">
	<tr>
		<th>ID Pariwisata</th>
		<th>ID Daerah</th>
		<th>Nama Tempat</th>
		<th>Alamat</th>
		<th>Biaya Masuk</th>
		<th>Deskripsi</th>
		<th>Average Rating</th>
		<th>Opsi</th>
	</tr>
	<?php $__currentLoopData = $pariwisata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pws): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td><?php echo e($pws->id_pariwisata); ?></td>
		<td><?php echo e($pws->id_daerah); ?></td>
		<td><?php echo e($pws->nama_tempat); ?></td>
		<td><?php echo e($pws->alamat_pariwisata); ?></td>
		<td><?php echo e($pws->biaya_masuk); ?></td>
		<td><?php echo e($pws->deskripsi_pariwisata); ?></td>
		<td><?php echo e($pws->avg_rating); ?></td>
		<td>
			<a href="/backend/pariwisata/edit/<?php echo e($pws->id_pariwisata); ?>">Edit</a>
			|
			<a href="/backend/pariwisata/hapus/<?php echo e($pws->id_pariwisata); ?>">Hapus</a>
		</td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wisata_pelesir\resources\views/index_pariwisata.blade.php ENDPATH**/ ?>