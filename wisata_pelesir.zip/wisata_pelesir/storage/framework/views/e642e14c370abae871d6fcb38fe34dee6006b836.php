<?php $__env->startSection('konten'); ?>

<table border="1">
	<tr>
		<th>ID</th>
		<th>Nama Admin</th>
		<th>Password</th>
		<th>Foto</th>
		<th>Opsi</th>
	</tr>
	<?php $__currentLoopData = $admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td><?php echo e($adm->id_admin); ?></td>
		<td><?php echo e($adm->administrator); ?></td>
		<td><?php echo e($adm->password); ?></td>
		<td><?php echo e($adm->foto_admin); ?></td>
		<td>
			<a href="/backend/admin/edit/<?php echo e($adm->id_admin); ?>">Edit</a>
			|
			<a href="/backend/admin/hapus/<?php echo e($adm->id_admin); ?>">Hapus</a>
		</td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wisata_pelesir\resources\views/admin.blade.php ENDPATH**/ ?>