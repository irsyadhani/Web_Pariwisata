<?php $__env->startSection('konten'); ?>
	<h3>Tambah Data Kategori</h3>
	<br>

	<form action="/backend/kategori/store" method="post">
		<?php echo e(csrf_field()); ?>

		ID :
		<input type="text" name="id" required="required">
		<br>
		Nama :
		<input type="text" name="nama" required="required">
		<br>
		<a href="/backend/kategori"><button type="button">Back</button></a>
		|
		<input type="submit" value="Simpan Data">
	</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wisata_pelesir\resources\views/tambah_kategori.blade.php ENDPATH**/ ?>