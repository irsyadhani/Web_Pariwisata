<?php $__env->startSection('konten'); ?>
<h3>Data Pengguna</h3>

<a href="/backend/pengguna/tambah">+ Tambah Data</a>

<br>

<table border="1">
	<tr>
		<th>ID</th>
		<th>Nama pengguna</th>
		<th>Password</th>
		<th>No telp</th>
		<th>Email</th>
		<th>Foto</th>
		<th>Opsi</th>
	</tr>
	<?php $__currentLoopData = $pengguna; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td><?php echo e($p->id_pengguna); ?></td>
		<td><?php echo e($p->nama_pengguna); ?></td>
		<td><?php echo e($p->kata_sandi); ?></td>
		<td><?php echo e($p->no_telp); ?></td>
		<td><?php echo e($p->email); ?></td>
		<td><?php echo e($p->foto_pengguna); ?></td>
		<td>
			<a href="/backend/pengguna/edit/<?php echo e($p->id_pengguna); ?>">Edit</a>
			|
			<a href="/backend/pengguna/hapus/<?php echo e($p->id_pengguna); ?>">Hapus</a>
		</td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wisata_pelesir\resources\views/index_pengguna.blade.php ENDPATH**/ ?>