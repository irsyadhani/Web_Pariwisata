<?php $__env->startSection('konten'); ?>
	<h3>Edit Data Kategori</h3>
	<br>

	<?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<form action="/backend/kategori/update" method="post">
			<?php echo e(csrf_field()); ?>

			<input type="hidden" name="id" value="<?php echo e($k->id_kategori); ?>">
			<br>
			Nama :
			<input type="text" name="nama" value="<?php echo e($k->nama_kategori); ?>" required="required">
			<br>
			<a href="/backend/kategori"><button type="button">Back</button></a>
			|
			<input type="submit" value="Simpan Data">
		</form>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wisata_pelesir\resources\views/edit_kategori.blade.php ENDPATH**/ ?>