<?php $__env->startSection('konten'); ?>
<h3>Data Foto Pariwisata</h3>

<a href="/backend/foto_pariwisata/tambah">+ Tambah Data</a>

<br>

<table border="1">
	<tr>
		<th>ID Foto</th>
		<th>ID Pariwisata</th>
		<th>Foto_pariwisata</th>
		<th>Opsi</th>
	</tr>
	<?php $__currentLoopData = $foto_pariwisata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td><?php echo e($fp->id_foto); ?></td>
		<td><?php echo e($fp->id_pariwisata); ?></td>
		<td><?php echo e($fp->foto_pariwisata); ?></td>
		<td>
			<a href="/backend/foto_pariwisata/edit/<?php echo e($fp->id_foto); ?>">Edit</a>
			|
			<a href="/backend/foto_pariwisata/hapus/<?php echo e($fp->id_foto); ?>">Hapus</a>
		</td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wisata_pelesir\resources\views/index_foto_pariwisata.blade.php ENDPATH**/ ?>